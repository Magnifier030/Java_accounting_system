package com.example.demo;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;


public class HelloController {
    @FXML
    protected void OnButton(MouseEvent m){
        m.
        b.setStyle("-fx-background-color: rgba(1,1,1,0.5);");
    }
    @FXML
    protected void LeaveButton(){

    }
}